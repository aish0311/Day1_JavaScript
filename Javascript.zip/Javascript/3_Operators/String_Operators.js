let s1 = "Abhishek";
let s2 = "Pujara";
let s3 = s1 + " " + s2;
document.write(s3);